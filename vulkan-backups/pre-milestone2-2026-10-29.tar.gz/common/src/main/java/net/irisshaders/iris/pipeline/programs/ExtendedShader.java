package net.irisshaders.iris.pipeline.programs;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import com.mojang.renderpearl.api.pipeline.BindGroupLayout;
import com.mojang.renderpearl.api.pipeline.BindGroupLayout.UniformDescription;
import com.mojang.renderpearl.api.vertex.VertexFormat;
import com.mojang.renderpearl.backend.opengl.GlProgram;
import com.mojang.renderpearl.backend.opengl.GlStateManager;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.caffeinemc.mods.sodium.client.render.chunk.ShaderChunkRenderer;
import net.irisshaders.iris.compat.SkipList;
import net.irisshaders.iris.gl.GLDebug;
import net.irisshaders.iris.gl.IrisRenderSystem;
import net.irisshaders.iris.gl.blending.AlphaTest;
import net.irisshaders.iris.gl.blending.BlendModeOverride;
import net.irisshaders.iris.gl.blending.BufferBlendOverride;
import net.irisshaders.iris.gl.blending.DepthColorStorage;
import net.irisshaders.iris.gl.framebuffer.GlFramebuffer;
import net.irisshaders.iris.gl.image.ImageHolder;
import net.irisshaders.iris.gl.program.ProgramImages;
import net.irisshaders.iris.gl.program.ProgramSamplers;
import net.irisshaders.iris.gl.program.ProgramUniforms;
import net.irisshaders.iris.gl.sampler.SamplerHolder;
import net.irisshaders.iris.gl.texture.TextureType;
import net.irisshaders.iris.gl.uniform.DynamicLocationalUniformHolder;
import net.irisshaders.iris.helpers.MatrixUtils;
import net.irisshaders.iris.mixinterface.ShaderInstanceInterface;
import net.irisshaders.iris.pipeline.IrisRenderingPipeline;
import net.irisshaders.iris.pipeline.transform.Patch;
import net.irisshaders.iris.samplers.IrisSamplers;
import net.irisshaders.iris.shadows.ShadowRenderer;
import net.irisshaders.iris.shadows.ShadowRenderingState;
import net.irisshaders.iris.uniforms.CapturedRenderingState;
import net.irisshaders.iris.uniforms.custom.CustomUniforms;
import net.irisshaders.iris.vertices.ImmediateState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BindGroupLayouts;
import net.minecraft.client.renderer.feature.ItemFeatureRenderer;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL46C;
import org.slf4j.Logger;

public class ExtendedShader extends GlProgram implements IrisProgram {
   private static final Matrix4f identity = new Matrix4f();
   private static final Logger LOGGER = LogUtils.getLogger();
   private static ExtendedShader lastApplied;
   private final boolean intensitySwizzle;
   private final List<BufferBlendOverride> bufferBlendOverrides;
   private final boolean hasOverrides;
   private final int modelViewInverse;
   private final int projectionInverse;
   private final Matrix3f normalMatrix = new Matrix3f();
   private final CustomUniforms customUniforms;
   private final IrisRenderingPipeline parent;
   private final ProgramUniforms uniforms;
   private final ProgramSamplers samplers;
   private final ProgramImages images;
   private final GlFramebuffer writingToBeforeTranslucent;
   private final GlFramebuffer writingToAfterTranslucent;
   private final BlendModeOverride blendModeOverride;
   private final float alphaTest;
   private final boolean usesTessellation;
   private final Matrix4f tempMatrix4f = new Matrix4f();
   private final Matrix3f tempMatrix3f = new Matrix3f();
   private final float[] tempFloats = new float[16];
   private final float[] tempFloats2 = new float[9];
   private final int normalMat;
   private boolean hasUV;
   private int textureToUnswizzle;
   private boolean isSetup;
   private final IrisRenderingPipeline pipeline;
   private float[] tempF = new float[9];

   public ExtendedShader(
      int programId,
      String string,
      VertexFormat vertexFormat,
      boolean usesTessellation,
      GlFramebuffer writingToBeforeTranslucent,
      GlFramebuffer writingToAfterTranslucent,
      BlendModeOverride blendModeOverride,
      AlphaTest alphaTest,
      Consumer<DynamicLocationalUniformHolder> uniformCreator,
      BiConsumer<SamplerHolder, ImageHolder> samplerCreator,
      ShaderKey shaderKey,
      IrisRenderingPipeline parent,
      @Nullable List<BufferBlendOverride> bufferBlendOverrides,
      CustomUniforms customUniforms,
      Patch patch
   ) throws IOException {
      super(programId, string);
      this.pipeline = parent;
      GLDebug.nameObject(33506, programId, string);
      ((ShaderInstanceInterface)this).setShouldSkip(SkipList.NONE);
      boolean has1 = false;
      boolean has2 = false;
      boolean has0 = false;
      if (vertexFormat.contains("UV0") || vertexFormat.contains("a_TexCoord")) {
         this.hasUV = true;
         has0 = true;
      }

      if (vertexFormat.contains("UV1")) {
         has1 = true;
      }

      if (vertexFormat.contains("UV2") || vertexFormat.contains("a_LightAndData")) {
         has2 = true;
      }

      List<UniformDescription> layouts = new ArrayList<>();
      if (patch == Patch.VANILLA) {
         BindGroupLayout samplr = null;
         if (has0) {
            if (has1) {
               if (has2) {
                  samplr = BindGroupLayouts.SAMPLER0_SAMPLER1_SAMPLER2;
               } else {
                  samplr = BindGroupLayouts.SAMPLER0_SAMPLER1;
               }
            } else if (has2) {
               samplr = BindGroupLayouts.SAMPLER0_SAMPLER2;
            } else {
               samplr = BindGroupLayouts.SAMPLER0;
            }
         }

         if (samplr != null) {
            layouts.addAll(samplr.uniforms());
         }

         layouts.addAll(BindGroupLayouts.DYNAMIC_TRANSFORMS.uniforms());
         layouts.addAll(BindGroupLayouts.CLOUD_INFO.uniforms());
         layouts.addAll(BindGroupLayouts.PROJECTION.uniforms());
         layouts.addAll(BindGroupLayouts.GLOBALS.uniforms());
         layouts.addAll(BindGroupLayouts.FOG.uniforms());
      } else {
         layouts.addAll(ShaderChunkRenderer.BIND_GROUP.uniforms());
      }

      super.setupBindGroupLayouts(layouts);
      ProgramUniforms.Builder uniformBuilder = ProgramUniforms.builder(string, programId);
      ProgramSamplers.Builder samplerBuilder = ProgramSamplers.builder(programId, IrisSamplers.WORLD_RESERVED_TEXTURE_UNITS);
      uniformCreator.accept(uniformBuilder);
      this.normalMat = GlStateManager._glGetUniformLocation(programId, "iris_NormalMat");
      ProgramImages.Builder builder = ProgramImages.builder(programId);
      samplerCreator.accept(samplerBuilder, builder);
      samplerBuilder.addDynamicSampler(TextureType.TEXTURE_2D, () -> this.getGlintSamplerFor(shaderKey, this.pipeline), null, "glintTexture");
      customUniforms.mapholderToPass(uniformBuilder, this);
      this.usesTessellation = usesTessellation;
      this.uniforms = uniformBuilder.buildUniforms();
      this.customUniforms = customUniforms;
      this.samplers = samplerBuilder.build();
      this.images = builder.build();
      this.writingToBeforeTranslucent = writingToBeforeTranslucent;
      this.writingToAfterTranslucent = writingToAfterTranslucent;
      this.blendModeOverride = blendModeOverride;
      this.bufferBlendOverrides = bufferBlendOverrides;
      this.hasOverrides = bufferBlendOverrides != null && !bufferBlendOverrides.isEmpty();
      this.alphaTest = alphaTest.reference();
      this.parent = parent;
      this.modelViewInverse = GlStateManager._glGetUniformLocation(programId, "iris_ModelViewMatInverse");
      this.projectionInverse = GlStateManager._glGetUniformLocation(programId, "iris_ProjMatInverse");
      this.intensitySwizzle = shaderKey.isIntensity();
   }

   private int getGlintSamplerFor(ShaderKey shaderKey, IrisRenderingPipeline pipeline) {
      if (!shaderKey.isGlint() || !shaderKey.getVertexFormat().contains("UV1")) {
         return pipeline.getWhitePixel().getTexture().iris$getGlId();
      } else {
         return shaderKey != ShaderKey.ENTITIES_CUTOUT_GLINT_ARMOR
               && shaderKey != ShaderKey.HAND_CUTOUT_GLINT_ARMOR
               && shaderKey != ShaderKey.HAND_TRANSLUCENT_GLINT_ARMOR
            ? Minecraft.getInstance().getTextureManager().getTexture(ItemFeatureRenderer.ENCHANTED_GLINT_ITEM).getTexture().iris$getGlId()
            : Minecraft.getInstance().getTextureManager().getTexture(ItemFeatureRenderer.ENCHANTED_GLINT_ARMOR).getTexture().iris$getGlId();
      }
   }

   public boolean isIntensitySwizzle() {
      return this.intensitySwizzle;
   }

   @Override
   public void iris$clearState() {
      ProgramUniforms.clearActiveUniforms();
      ProgramSamplers.clearActiveSamplers();
      if (this.blendModeOverride != null || this.hasOverrides) {
         BlendModeOverride.restore();
      }

      this.isSetup = false;
   }

   @Override
   public void iris$setupState(List<UniformDescription> samplers) {
      this.isSetup = true;
      DepthColorStorage.unlockDepthColor();
      CapturedRenderingState.INSTANCE.setCurrentAlphaTest(this.alphaTest);
      GlStateManager._glUseProgram(this.getProgramId());
      if (this.modelViewInverse > -1) {
         IrisRenderSystem.uniformMatrix4fv(this.modelViewInverse, false, RenderSystem.getModelViewMatrixCopy().invert(this.tempMatrix4f).get(this.tempFloats));
      }

      if (this.normalMat > -1) {
         this.tempF = RenderSystem.getModelViewMatrixCopy().invert(this.tempMatrix4f).transpose3x3(this.normalMatrix).get(this.tempF);
         IrisRenderSystem.uniformMatrix3fv(this.normalMat, false, this.tempF);
      }

      if (this.projectionInverse > -1) {
         IrisRenderSystem.uniformMatrix4fv(
            this.projectionInverse,
            false,
            (ShadowRenderingState.areShadowsCurrentlyBeingRendered()
                  ? MatrixUtils.undoRevZ(ShadowRenderer.PROJECTION)
                  : CapturedRenderingState.INSTANCE.getGbufferProjection())
               .invert(this.tempMatrix4f)
               .get(this.tempFloats)
         );
      }

      ImmediateState.usingTessellation = this.usesTessellation;
      if (!this.hasUV) {
         IrisRenderSystem.bindTextureToUnit(3553, 0, this.pipeline.getWhitePixel().getTexture().iris$getGlId());
      }

      this.samplers.update();
      this.uniforms.update();
      this.customUniforms.push(this);
      this.images.update();
      BlendModeOverride.restore();
      if (this.blendModeOverride != null) {
         this.blendModeOverride.apply();
      }

      if (this.hasOverrides) {
         this.bufferBlendOverrides.forEach(BufferBlendOverride::apply);
      }

      if (this.parent.isBeforeTranslucent) {
         this.writingToBeforeTranslucent.bind();
      } else {
         this.writingToAfterTranslucent.bind();
      }
   }

   public boolean hasActiveImages() {
      return this.images.getActiveImages() > 0;
   }

   @Override
   public int iris$getBlockIndex(int program, CharSequence uniformBlockName) {
      return ((String)uniformBlockName).contains("u_")
         ? GL46C.glGetUniformBlockIndex(program, uniformBlockName)
         : GL46C.glGetUniformBlockIndex(program, "iris_" + uniformBlockName);
   }

   public boolean usesTessellation() {
      return this.usesTessellation;
   }

   @Override
   public boolean iris$isSetUp() {
      return this.isSetup;
   }

   static {
      identity.identity();
   }
}

package net.irisshaders.iris.uniforms.custom.cached;

import kroppeb.stareval.function.FunctionReturn;
import kroppeb.stareval.function.Type;
import net.irisshaders.iris.gl.IrisRenderSystem;
import net.irisshaders.iris.gl.uniform.FloatSupplier;
import net.irisshaders.iris.gl.uniform.UniformUpdateFrequency;

public class FloatCachedUniform extends CachedUniform {
   private final FloatSupplier supplier;
   private float cached;

   public FloatCachedUniform(String name, UniformUpdateFrequency updateFrequency, FloatSupplier supplier) {
      super(name, updateFrequency);
      this.supplier = supplier;
   }

   @Override
   protected boolean doUpdate() {
      float prev = this.cached;
      this.cached = this.supplier.getAsFloat();
      return prev != this.cached;
   }

   @Override
   public void push(int location) {
      IrisRenderSystem.uniform1f(location, this.cached);
   }

   @Override
   public void writeTo(FunctionReturn functionReturn) {
      functionReturn.floatReturn = this.cached;
   }

   @Override
   public Type getType() {
      return Type.Float;
   }
}

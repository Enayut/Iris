package net.irisshaders.iris.shaderpack.option.menu;

import java.util.List;
import java.util.Optional;
import net.irisshaders.iris.shaderpack.option.ShaderPackOptions;
import net.irisshaders.iris.shaderpack.properties.ShaderProperties;

public class OptionMenuMainElementScreen extends OptionMenuElementScreen {
   public OptionMenuMainElementScreen(
      OptionMenuContainer container,
      ShaderProperties shaderProperties,
      ShaderPackOptions shaderPackOptions,
      List<String> elementStrings,
      Optional<Integer> columnCount
   ) {
      super(container, shaderProperties, shaderPackOptions, elementStrings, columnCount);
   }
}

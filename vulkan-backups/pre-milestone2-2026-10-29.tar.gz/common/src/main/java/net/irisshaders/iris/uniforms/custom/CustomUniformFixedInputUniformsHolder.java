package net.irisshaders.iris.uniforms.custom;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.UnmodifiableIterator;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Collection;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleSupplier;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import kroppeb.stareval.function.Type;
import net.irisshaders.iris.Iris;
import net.irisshaders.iris.gl.uniform.FloatSupplier;
import net.irisshaders.iris.gl.uniform.UniformHolder;
import net.irisshaders.iris.gl.uniform.UniformType;
import net.irisshaders.iris.gl.uniform.UniformUpdateFrequency;
import net.irisshaders.iris.uniforms.custom.cached.BooleanCachedUniform;
import net.irisshaders.iris.uniforms.custom.cached.CachedUniform;
import net.irisshaders.iris.uniforms.custom.cached.Float2VectorCachedUniform;
import net.irisshaders.iris.uniforms.custom.cached.Float3MatrixCachedUniform;
import net.irisshaders.iris.uniforms.custom.cached.Float3VectorCachedUniform;
import net.irisshaders.iris.uniforms.custom.cached.Float4MatrixCachedUniform;
import net.irisshaders.iris.uniforms.custom.cached.Float4VectorCachedUniform;
import net.irisshaders.iris.uniforms.custom.cached.FloatCachedUniform;
import net.irisshaders.iris.uniforms.custom.cached.Int2VectorCachedUniform;
import net.irisshaders.iris.uniforms.custom.cached.Int3VectorCachedUniform;
import net.irisshaders.iris.uniforms.custom.cached.IntCachedUniform;
import org.joml.Matrix3fc;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector2f;
import org.joml.Vector2i;
import org.joml.Vector3d;
import org.joml.Vector3f;
import org.joml.Vector3i;
import org.joml.Vector4f;

public class CustomUniformFixedInputUniformsHolder {
   private final ImmutableMap<String, CachedUniform> inputVariables;

   public CustomUniformFixedInputUniformsHolder(ImmutableMap<String, CachedUniform> inputVariables) {
      this.inputVariables = inputVariables;
   }

   public Type getType(String name) {
      CachedUniform uniform = (CachedUniform)this.inputVariables.get(name);
      return uniform == null ? null : uniform.getType();
   }

   public boolean containsKey(String name) {
      return this.inputVariables.containsKey(name);
   }

   public CachedUniform getUniform(String name) {
      return (CachedUniform)this.inputVariables.get(name);
   }

   public void updateAll() {
      UnmodifiableIterator var1 = this.inputVariables.values().iterator();

      while (var1.hasNext()) {
         CachedUniform value = (CachedUniform)var1.next();
         value.update();
      }
   }

   public Collection<CachedUniform> getAll() {
      return this.inputVariables.values();
   }

   public static class Builder implements UniformHolder {
      private final Map<String, CachedUniform> inputVariables = new Object2ObjectOpenHashMap();

      private CustomUniformFixedInputUniformsHolder.Builder put(String name, CachedUniform uniform) {
         if (this.inputVariables.containsKey(name)) {
            Iris.logger.warn("Duplicated fixed uniform supplied as inputs to the Custom uniform holder: " + name);
            return this;
         } else {
            this.inputVariables.put(name, uniform);
            return this;
         }
      }

      public CustomUniformFixedInputUniformsHolder.Builder uniform1f(UniformUpdateFrequency updateFrequency, String name, FloatSupplier value) {
         return this.put(name, new FloatCachedUniform(name, updateFrequency, value));
      }

      public CustomUniformFixedInputUniformsHolder.Builder uniform1f(UniformUpdateFrequency updateFrequency, String name, IntSupplier value) {
         return this.put(name, new FloatCachedUniform(name, updateFrequency, value::getAsInt));
      }

      public CustomUniformFixedInputUniformsHolder.Builder uniform1f(UniformUpdateFrequency updateFrequency, String name, DoubleSupplier value) {
         return this.put(name, new FloatCachedUniform(name, updateFrequency, () -> (float)value.getAsDouble()));
      }

      public CustomUniformFixedInputUniformsHolder.Builder uniform1i(UniformUpdateFrequency updateFrequency, String name, IntSupplier value) {
         return this.put(name, new IntCachedUniform(name, updateFrequency, value));
      }

      public CustomUniformFixedInputUniformsHolder.Builder uniform1b(UniformUpdateFrequency updateFrequency, String name, BooleanSupplier value) {
         return this.put(name, new BooleanCachedUniform(name, updateFrequency, value));
      }

      public CustomUniformFixedInputUniformsHolder.Builder uniform2f(UniformUpdateFrequency updateFrequency, String name, Supplier<Vector2f> value) {
         return this.put(name, new Float2VectorCachedUniform(name, updateFrequency, value));
      }

      public CustomUniformFixedInputUniformsHolder.Builder uniform2i(UniformUpdateFrequency updateFrequency, String name, Supplier<Vector2i> value) {
         return this.put(name, new Int2VectorCachedUniform(name, updateFrequency, value));
      }

      public CustomUniformFixedInputUniformsHolder.Builder uniform3f(UniformUpdateFrequency updateFrequency, String name, Supplier<Vector3f> value) {
         return this.put(name, new Float3VectorCachedUniform(name, updateFrequency, value));
      }

      public CustomUniformFixedInputUniformsHolder.Builder uniform3i(UniformUpdateFrequency updateFrequency, String name, Supplier<Vector3i> value) {
         return this.put(name, new Int3VectorCachedUniform(name, updateFrequency, value));
      }

      public CustomUniformFixedInputUniformsHolder.Builder uniformTruncated3f(UniformUpdateFrequency updateFrequency, String name, Supplier<Vector4f> value) {
         Vector3f held = new Vector3f();
         return this.put(name, new Float3VectorCachedUniform(name, updateFrequency, () -> {
            Vector4f vec = value.get();
            held.set(vec.x(), vec.y(), vec.z());
            return held;
         }));
      }

      @Override
      public UniformHolder uniform3d(UniformUpdateFrequency updateFrequency, String name, Supplier<Vector3d> value) {
         Vector3f held = new Vector3f();
         return this.put(name, new Float3VectorCachedUniform(name, updateFrequency, () -> {
            Vector3d vec = value.get();
            held.set(vec.x(), vec.y(), vec.z());
            return held;
         }));
      }

      @Override
      public UniformHolder uniform4f(UniformUpdateFrequency updateFrequency, String name, Supplier<Vector4f> value) {
         Vector4f held = new Vector4f();
         return this.put(name, new Float4VectorCachedUniform(name, updateFrequency, () -> {
            Vector4f vec = value.get();
            held.set(vec.x(), vec.y(), vec.z(), vec.w());
            return held;
         }));
      }

      @Override
      public UniformHolder uniform4fArray(UniformUpdateFrequency updateFrequency, String name, Supplier<float[]> value) {
         Vector4f held = new Vector4f();
         return this.put(name, new Float4VectorCachedUniform(name, updateFrequency, () -> {
            float[] vec = value.get();
            held.set(vec);
            return held;
         }));
      }

      @Override
      public UniformHolder uniformMatrix(UniformUpdateFrequency updateFrequency, String name, Supplier<Matrix4fc> value) {
         return this.put(name, new Float4MatrixCachedUniform(name, updateFrequency, value));
      }

      @Override
      public UniformHolder uniformMatrix3(UniformUpdateFrequency updateFrequency, String name, Supplier<Matrix3fc> value) {
         return this.put(name, new Float3MatrixCachedUniform(name, updateFrequency, value));
      }

      @Override
      public UniformHolder uniformMatrixFromArray(UniformUpdateFrequency updateFrequency, String name, Supplier<float[]> value) {
         Matrix4f held = new Matrix4f();
         return this.put(name, new Float4MatrixCachedUniform(name, updateFrequency, () -> {
            held.set(value.get());
            return held;
         }));
      }

      @Override
      public UniformHolder externallyManagedUniform(String name, UniformType type) {
         return this;
      }

      public CustomUniformFixedInputUniformsHolder build() {
         return new CustomUniformFixedInputUniformsHolder(ImmutableMap.copyOf(this.inputVariables));
      }
   }
}

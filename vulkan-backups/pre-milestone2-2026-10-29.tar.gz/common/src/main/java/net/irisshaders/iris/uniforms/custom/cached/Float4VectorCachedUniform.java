package net.irisshaders.iris.uniforms.custom.cached;

import java.util.function.Supplier;
import net.irisshaders.iris.gl.IrisRenderSystem;
import net.irisshaders.iris.gl.uniform.UniformUpdateFrequency;
import net.irisshaders.iris.parsing.VectorType;
import org.joml.Vector4f;

public class Float4VectorCachedUniform extends VectorCachedUniform<Vector4f> {
   public Float4VectorCachedUniform(String name, UniformUpdateFrequency updateFrequency, Supplier<Vector4f> supplier) {
      super(name, updateFrequency, new Vector4f(), supplier);
   }

   protected void setFrom(Vector4f other) {
      this.cached.set(other);
   }

   @Override
   public void push(int location) {
      IrisRenderSystem.uniform4f(location, this.cached.x, this.cached.y, this.cached.z, this.cached.w);
   }

   public VectorType getType() {
      return VectorType.VEC4;
   }
}

package net.irisshaders.iris.uniforms;

import net.minecraft.client.Minecraft;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3d;

public class CapturedRenderingState {
   public static final CapturedRenderingState INSTANCE = new CapturedRenderingState();
   private static final Vector3d ZERO_VECTOR_3d = new Vector3d();
   private Matrix4fc gbufferModelView;
   private Matrix4fc gbufferProjection;
   private Vector3d fogColor;
   private float fogDensity;
   private float darknessLightFactor;
   private float tickDelta;
   private float realTickDelta;
   private int currentRenderedBlockEntity;
   private int currentRenderedEntity = -1;
   private int currentRenderedItem = -1;
   private int textureReloadCount = 0;
   private float currentAlphaTest;
   private float cloudTime;

   private CapturedRenderingState() {
   }

   public Matrix4fc getGbufferModelView() {
      return this.gbufferModelView;
   }

   public void setGbufferModelView(Matrix4fc gbufferModelView) {
      this.gbufferModelView = gbufferModelView;
   }

   public Matrix4fc getGbufferProjection() {
      return this.gbufferProjection;
   }

   public void setGbufferProjection(Matrix4f gbufferProjection) {
      this.gbufferProjection = new Matrix4f(gbufferProjection);
   }

   public Vector3d getFogColor() {
      return Minecraft.getInstance().level != null && this.fogColor != null ? this.fogColor : ZERO_VECTOR_3d;
   }

   public void setFogColor(float red, float green, float blue) {
      this.fogColor = new Vector3d(red, green, blue);
   }

   public float getFogDensity() {
      return this.fogDensity;
   }

   public void setFogDensity(float fogDensity) {
      this.fogDensity = fogDensity;
   }

   public float getTickDelta() {
      return this.tickDelta;
   }

   public void setTickDelta(float tickDelta) {
      this.tickDelta = tickDelta;
   }

   public float getRealTickDelta() {
      return this.realTickDelta;
   }

   public void setRealTickDelta(float tickDelta) {
      this.realTickDelta = tickDelta;
   }

   public void setCurrentBlockEntity(int entity) {
      this.currentRenderedBlockEntity = entity;
   }

   public int getCurrentRenderedBlockEntity() {
      return this.currentRenderedBlockEntity;
   }

   public void setCurrentEntity(int entity) {
      this.currentRenderedEntity = entity;
   }

   public int getCurrentRenderedEntity() {
      return this.currentRenderedEntity;
   }

   public int getCurrentRenderedItem() {
      return this.currentRenderedItem;
   }

   public void setCurrentRenderedItem(int item) {
      this.currentRenderedItem = item;
   }

   public float getCurrentAlphaTest() {
      return this.currentAlphaTest;
   }

   public void setCurrentAlphaTest(float alphaTest) {
      this.currentAlphaTest = alphaTest;
   }

   public float getDarknessLightFactor() {
      return this.darknessLightFactor;
   }

   public void setDarknessLightFactor(float factor) {
      this.darknessLightFactor = factor;
   }

   public float getCloudTime() {
      return this.cloudTime;
   }

   public void setCloudTime(float cloudTime) {
      this.cloudTime = cloudTime;
   }

   public int getTextureReloadCount() {
      return this.textureReloadCount;
   }

   public void incrementTextureReloadCount() {
      this.textureReloadCount++;
   }

   public void resetTextureReloadCount() {
      this.textureReloadCount = 0;
   }
}

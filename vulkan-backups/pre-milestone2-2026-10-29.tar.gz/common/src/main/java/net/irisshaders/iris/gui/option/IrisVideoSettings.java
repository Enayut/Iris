package net.irisshaders.iris.gui.option;

import java.io.IOException;
import net.irisshaders.iris.Iris;
import net.irisshaders.iris.pathways.colorspace.ColorSpace;
import net.irisshaders.iris.pipeline.WorldRenderingPipeline;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.OptionInstance.IntRange;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.network.chat.Component;

public class IrisVideoSettings {
   private static final Tooltip DISABLED_TOOLTIP = Tooltip.create(Component.translatable("options.iris.shadowDistance.disabled"));
   private static final Tooltip ENABLED_TOOLTIP = Tooltip.create(Component.translatable("options.iris.shadowDistance.enabled"));
   public static int shadowDistance = 32;
   public static ColorSpace colorSpace = ColorSpace.SRGB;
   public static final OptionInstance<Integer> RENDER_DISTANCE = new ShadowDistanceOption<>(
      "options.iris.shadowDistance",
      mc -> {
         WorldRenderingPipeline pipeline = Iris.getPipelineManager().getPipelineNullable();
         Tooltip tooltip;
         if (pipeline != null) {
            if (pipeline.getForcedShadowRenderDistanceChunksForDisplay().isPresent()) {
               tooltip = DISABLED_TOOLTIP;
            } else {
               tooltip = ENABLED_TOOLTIP;
            }
         } else {
            tooltip = ENABLED_TOOLTIP;
         }

         return tooltip;
      },
      (arg, d) -> {
         WorldRenderingPipeline pipeline = Iris.getPipelineManager().getPipelineNullable();
         if (pipeline != null) {
            d = pipeline.getForcedShadowRenderDistanceChunksForDisplay().orElse(d);
         }

         return d.intValue() <= 0.0
            ? Component.translatable("options.generic_value", new Object[]{Component.translatable("options.iris.shadowDistance"), "0 (disabled)"})
            : Component.translatable(
               "options.generic_value",
               new Object[]{Component.translatable("options.iris.shadowDistance"), Component.translatable("options.chunks", new Object[]{d})}
            );
      },
      new IntRange(0, 32),
      getOverriddenShadowDistance(shadowDistance),
      integer -> {
         shadowDistance = integer;

         try {
            Iris.getIrisConfig().save();
         } catch (IOException e) {
            Iris.logger.fatal("Failed to save config!", e);
         }
      }
   );

   public static int getOverriddenShadowDistance(int base) {
      return Iris.getPipelineManager().getPipeline().map(pipeline -> pipeline.getForcedShadowRenderDistanceChunksForDisplay().orElse(base)).orElse(base);
   }

   public static boolean isShadowDistanceSliderEnabled() {
      return Iris.getPipelineManager().getPipeline().map(pipeline -> pipeline.getForcedShadowRenderDistanceChunksForDisplay().isEmpty()).orElse(true);
   }
}
